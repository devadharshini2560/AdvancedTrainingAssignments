package com.third;

public abstract class Instrument {
	public abstract void play();
}
